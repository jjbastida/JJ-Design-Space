<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Blank</title>
    <link rel="stylesheet" href="css/style.css">
    <?php
        include php/connect.php; //BE SURE TO CONFIGURE THIS WITH YOUR SETTINGS
    ?>
</head>

<body>
    
    <script src="js/script.js"></script>
</body>

</html>